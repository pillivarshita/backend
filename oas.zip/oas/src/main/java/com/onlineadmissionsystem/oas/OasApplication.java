package com.onlineadmissionsystem.oas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OasApplication {

	public static void main(String[] args) {
		SpringApplication.run(OasApplication.class, args);
	}

}
