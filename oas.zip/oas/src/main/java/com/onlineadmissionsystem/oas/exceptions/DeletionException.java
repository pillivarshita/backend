package com.onlineadmissionsystem.oas.exceptions;

public class DeletionException extends RuntimeException{
public DeletionException() {
		
	}
	public DeletionException(String message) {
		super(message);
	}
}