package com.onlineadmissionsystem.oas.exceptions;

public class PaymentAddException extends RuntimeException{
	public PaymentAddException() {}
	
	public PaymentAddException(String message) {
		super(message);
	}

}
