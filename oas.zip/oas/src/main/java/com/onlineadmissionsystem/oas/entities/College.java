package com.onlineadmissionsystem.oas.entities;


import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;



@Entity
public class College {
	
	
	
		@Id
		@SequenceGenerator(name="collegeRegId",allocationSize=1)
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private int collegeRegId;
		
		
		   private String collegeName;
		 
		   private String address;
		 
		
		 
		 
		 public College() {
			 
		 }




		public College(String collegeName, String address) {
			super();
			this.collegeName = collegeName;
			this.address = address;
		}




		public College(int collegeRegId, String collegeName, String address) {
			super();
			this.collegeRegId = collegeRegId;
			this.collegeName = collegeName;
			this.address = address;
		}




		public int getCollegeRegId() {
			return collegeRegId;
		}




		public void setCollegeRegId(int collegeRegId) {
			this.collegeRegId = collegeRegId;
		}




		public String getCollegeName() {
			return collegeName;
		}




		public void setCollegeName(String collegeName) {
			this.collegeName = collegeName;
		}




		public String getAddress() {
			return address;
		}




		public void setAddress(String address) {
			this.address = address;
		}

}